import csv
import os
import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# 1. SYSTEM PARAMETERS
# ============================================================

M = 8                  # Number of delay bins
N = 8                  # Number of Doppler bins
NUM_BITS = 2 * M * N   # QPSK: 2 bits/symbol

SNR_VALUES = [0, 5, 10, 15, 20, 25]

NUM_FRAMES = 100


# ============================================================
# 2. QPSK MODULATION
# ============================================================

def qpsk_mod(bits):

    bits = np.array(bits).reshape(-1, 2)

    symbols = (
        (1 - 2 * bits[:, 0])
        + 1j * (1 - 2 * bits[:, 1])
    ) / np.sqrt(2)

    return symbols


# ============================================================
# 3. QPSK DEMODULATION
# ============================================================

def qpsk_demod(symbols):

    bits_i = (np.real(symbols) < 0).astype(int)
    bits_q = (np.imag(symbols) < 0).astype(int)

    bits = np.column_stack((bits_i, bits_q))

    return bits.flatten()


# ============================================================
# 4. OTFS MODULATION
#
# Simplified delay-Doppler OTFS model.
# For the first review, this gives you a clean
# software simulation framework.
# ============================================================

def otfs_modulate(symbols):

    return symbols.reshape(M, N)


# ============================================================
# 5. OTFS DEMODULATION
# ============================================================

def otfs_demodulate(grid):

    return grid.flatten()


# ============================================================
# 6. CREATE A DOPPLER + DELAY CHANNEL
# ============================================================

def generate_channel():

    H = np.zeros((M, N), dtype=complex)

    # Direct path
    H[0, 0] = 1.0

    # Multipath components
    H[1, 1] = 0.5 * np.exp(1j * np.random.uniform(0, 2*np.pi))
    H[2, 3] = 0.3 * np.exp(1j * np.random.uniform(0, 2*np.pi))

    # Doppler component
    H[0, 2] = 0.2 * np.exp(1j * np.random.uniform(0, 2*np.pi))

    return H


# ============================================================
# 7. APPLY DELAY-DOPPLER CHANNEL
# ============================================================

def apply_channel(x, H):

    y = np.zeros_like(x, dtype=complex)

    for delay in range(M):

        for doppler in range(N):

            if H[delay, doppler] != 0:

                shifted = np.roll(
                    x,
                    shift=(delay, doppler),
                    axis=(0, 1)
                )

                y += H[delay, doppler] * shifted

    return y


# ============================================================
# 8. ADD AWGN
# ============================================================

def add_awgn(signal, snr_db):

    signal_power = np.mean(np.abs(signal) ** 2)

    snr_linear = 10 ** (snr_db / 10)

    noise_power = signal_power / snr_linear

    noise = np.sqrt(noise_power / 2) * (
        np.random.randn(*signal.shape)
        + 1j * np.random.randn(*signal.shape)
    )

    return signal + noise


# ============================================================
# 9. MMSE DETECTOR
# ============================================================

def mmse_detector(y, H, snr_db):

    h = H[0, 0]

    snr_linear = 10 ** (snr_db / 10)

    noise_variance = 1 / snr_linear

    estimate = (
        np.conj(h)
        /
        (np.abs(h)**2 + noise_variance)
    ) * y

    return estimate


# ============================================================
# 10. ZF DETECTOR
# ============================================================

def zf_detector(y, H):

    h = H[0, 0]

    if abs(h) < 1e-12:
        h = 1e-12

    estimate = y / h

    return estimate


# ============================================================
# 11. ITERATIVE DETECTOR
#
# Simplified iterative refinement detector.
# ============================================================

def iterative_detector(y, H, snr_db, iterations=5):

    estimate = mmse_detector(y, H, snr_db)

    for _ in range(iterations):

        hard = np.sign(np.real(estimate)) \
               + 1j * np.sign(np.imag(estimate))

        hard = hard / np.sqrt(2)

        estimate = 0.7 * estimate + 0.3 * hard

    return estimate


# ============================================================
# 12. MESSAGE PASSING STYLE DETECTOR
#
# Simplified iterative detector representing a
# higher-complexity detection option.
# ============================================================

def message_passing_detector(y, H, snr_db, iterations=15):

    estimate = mmse_detector(y, H, snr_db)

    for _ in range(iterations):

        hard = np.sign(np.real(estimate)) \
               + 1j * np.sign(np.imag(estimate))

        hard = hard / np.sqrt(2)

        estimate = 0.5 * estimate + 0.5 * hard

    return estimate


# ============================================================
# 13. BER CALCULATION
# ============================================================

def calculate_ber(original_bits, detected_bits):

    errors = np.sum(original_bits != detected_bits)

    return errors / len(original_bits)


# ============================================================
# 14. RUN ONE OTFS FRAME
# ============================================================

def run_frame(snr_db, detector):

    bits = np.random.randint(0, 2, NUM_BITS)

    symbols = qpsk_mod(bits)

    tx_grid = otfs_modulate(symbols)

    H = generate_channel()

    received = apply_channel(tx_grid, H)

    received = add_awgn(received, snr_db)

    if detector == "MMSE":

        detected_grid = mmse_detector(
            received,
            H,
            snr_db
        )

    elif detector == "ITERATIVE":

        detected_grid = iterative_detector(
            received,
            H,
            snr_db
        )

    elif detector == "MP":

        detected_grid = message_passing_detector(
            received,
            H,
            snr_db
        )

    elif detector == "ZF":

        detected_grid = zf_detector(
            received,
            H
        )

    else:

        raise ValueError("Unknown detector")

    detected_symbols = otfs_demodulate(
        detected_grid
    )

    detected_bits = qpsk_demod(
        detected_symbols
    )

    ber = calculate_ber(
        bits,
        detected_bits
    )

    return ber


# ============================================================
# 15. BER VS SNR SIMULATION
# ============================================================

def run_ber_simulation():

    detectors = [
        "MMSE",
        "ITERATIVE",
        "MP"
    ]

    results = {}

    for detector in detectors:

        ber_values = []

        print("\nRunning:", detector)

        for snr in SNR_VALUES:

            frame_errors = []

            for _ in range(NUM_FRAMES):

                ber = run_frame(
                    snr,
                    detector
                )

                frame_errors.append(ber)

            average_ber = np.mean(
                frame_errors
            )

            ber_values.append(
                average_ber
            )

            print(
                "SNR:",
                snr,
                "BER:",
                average_ber
            )

        results[detector] = ber_values

    # Append results to the existing CSV without deleting old results.
    csv_name = "OTFS_results.csv"
    file_is_empty = (
        not os.path.exists(csv_name)
        or os.path.getsize(csv_name) == 0
    )

    # Make sure a previous last row ends with a newline before appending.
    if not file_is_empty:
        with open(csv_name, "rb") as f:
            f.seek(-1, os.SEEK_END)
            needs_newline = f.read(1) not in (b"\n", b"\r")
    else:
        needs_newline = False

    with open(csv_name, "a", newline="", encoding="utf-8") as file:
        if needs_newline:
            file.write("\r\n")
        writer = csv.writer(file)

        # Write the header only if the file is new or empty.
        if file_is_empty:
            writer.writerow(
                ["SNR_dB", "MMSE_BER", "ITERATIVE_BER", "MP_BER"]
            )

        # Append this run's results after the existing rows.
        for i, snr in enumerate(SNR_VALUES):
            writer.writerow([
                snr,
                results["MMSE"][i],
                results["ITERATIVE"][i],
                results["MP"][i]
            ])

    print("\nAppended new BER results to OTFS_results.csv")
    return results


# ============================================================
# 16. PLOT BER VS SNR
# ============================================================

def plot_ber(results):

    plt.figure(figsize=(8, 5))

    for detector, values in results.items():

        plt.semilogy(
            SNR_VALUES,
            values,
            marker='o',
            label=detector
        )

    plt.xlabel("SNR (dB)")
    plt.ylabel("Bit Error Rate")

    plt.title(
        "OTFS Detector Performance"
    )

    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig("OTFS_detector_performance.png", dpi=200)
    print("Saved BER graph to OTFS_detector_performance.png")
    plt.show()


# ============================================================
# 17. COMPLEXITY ESTIMATION
# ============================================================

def estimate_complexity():

    complexity = {

        "MMSE": 1.0,

        "ITERATIVE": 5.0,

        "MP": 15.0

    }

    print("\nEstimated Relative Complexity")

    for detector, value in complexity.items():

        print(
            detector,
            ":",
            value,
            "units"
        )

    return complexity


# ============================================================
# 18. REINFORCEMENT LEARNING: CONTEXTUAL BANDIT (LinUCB)
# ============================================================

class ContextualBandit:
    """A simple LinUCB contextual bandit using SNR and Doppler as context."""

    def __init__(self, num_actions=3, alpha=0.7):
        self.num_actions = num_actions
        self.alpha = alpha
        self.context_size = 4
        self.A = [np.eye(self.context_size) for _ in range(num_actions)]
        self.b = [np.zeros(self.context_size) for _ in range(num_actions)]
        self.counts = np.zeros(num_actions, dtype=int)
        self.reward_sums = np.zeros(num_actions, dtype=float)

    @staticmethod
    def make_context(snr, doppler):
        # Normalize inputs to roughly 0-1 ranges and include an interaction feature.
        snr_norm = float(np.clip(snr / 30.0, 0.0, 1.0))
        doppler_norm = float(np.clip(doppler / 1000.0, 0.0, 1.0))
        return np.array([1.0, snr_norm, doppler_norm, snr_norm * doppler_norm])

    def select_action(self, snr, doppler, explore=True):
        x = self.make_context(snr, doppler)
        scores = []
        for action in range(self.num_actions):
            A_inv = np.linalg.inv(self.A[action])
            theta = A_inv @ self.b[action]
            estimate = float(theta @ x)
            uncertainty = float(np.sqrt(max(0.0, x @ A_inv @ x)))
            scores.append(estimate + (self.alpha * uncertainty if explore else 0.0))
        return int(np.argmax(scores))

    def update(self, action, snr, doppler, reward):
        x = self.make_context(snr, doppler)
        self.A[action] += np.outer(x, x)
        self.b[action] += reward * x
        self.counts[action] += 1
        self.reward_sums[action] += reward

    def average_reward(self, action):
        if self.counts[action] == 0:
            return 0.0
        return self.reward_sums[action] / self.counts[action]


# ============================================================
# 19. TRAIN CONTEXTUAL BANDIT
# ============================================================

def contextual_bandit_demo(episodes=200):
    bandit = ContextualBandit()
    detector_names = ["MMSE", "ITERATIVE", "MP"]
    complexity_penalty = {"MMSE": 0.05, "ITERATIVE": 0.15, "MP": 0.30}

    print("\nReinforcement Learning - Contextual Bandit (LinUCB)")
    print("Training with SNR and Doppler as context...")

    for _ in range(episodes):
        snr = np.random.uniform(0, 30)
        doppler = np.random.uniform(0, 1000)
        action = bandit.select_action(snr, doppler, explore=True)
        detector = detector_names[action]
        ber = run_frame(snr, detector)
        reward = float(np.clip(1.0 - ber - complexity_penalty[detector], 0.0, 1.0))
        bandit.update(action, snr, doppler, reward)

    print("\nTraining summary (average observed reward; not BER or accuracy):")
    for action, detector in enumerate(detector_names):
        print(f"{detector}: {bandit.average_reward(action):.4f}  (selected {bandit.counts[action]} times)")

    # Evaluate the learned policy without exploration on fixed demonstration contexts.
    test_cases = [(25, 50), (15, 300), (5, 800), (20, 100), (8, 700)]
    print("\nContextual Bandit - detector choices after training")
    for snr, doppler in test_cases:
        action = bandit.select_action(snr, doppler, explore=False)
        print(f"SNR: {snr} dB | Doppler: {doppler} Hz | Selected: {detector_names[action]}")

    return bandit


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    print(
        "======================================"
    )

    print(
        "ADAPTIVE OTFS RECEIVER SIMULATION"
    )

    print(
        "======================================"
    )

    # Step 1:
    # BER simulation

    results = run_ber_simulation()

    # Step 2:
    # Plot BER

    plot_ber(
        results
    )

    # Step 3:
    # Complexity

    estimate_complexity()

    # Step 4:
    # Train and demonstrate the context-aware bandit

    contextual_bandit_demo()